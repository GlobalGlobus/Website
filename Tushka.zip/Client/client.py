import socket
import threading
import pygame
import time

# Инициализация pygame для воспроизведения звука
pygame.mixer.init()

# Версия клиента
CLIENT_VERSION = "0.1"

def play_sound(sound_file):
    """
    Функция для воспроизведения звука.
    """
    try:
        sound = pygame.mixer.Sound(sound_file)  # Загружаем звук
        sound.play()  # Воспроизводим звук
    except Exception as e:
        print(f"Ошибка при воспроизведении звука {sound_file}: {e}")

def receive_messages(client_socket):
    """
    Функция для получения сообщений от сервера.
    """
    try:
        while True:
            message = client_socket.recv(1024).decode("utf-8")
            if not message:
                print("Сервер отключился.")
                break
            print(message)
            # Воспроизводим звук при получении сообщения
            play_sound("sound.mp3")
    except (ConnectionResetError, BrokenPipeError):
        print("Соединение потеряно.")
    finally:
        client_socket.close()
        print("Клиент отключен.")

def start_client(host='127.0.0.1', port=12345):
    """
    Функция для запуска клиента.
    """
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        client_socket.connect((host, port))
        print(f"Подключен к серверу {host}:{port}")

        # Отправляем версию клиента
        client_socket.sendall(CLIENT_VERSION.encode("utf-8"))

        # Получаем ответ от сервера о поддержке версии
        version_response = client_socket.recv(1024).decode("utf-8")
        print(version_response)

        if "устарела" in version_response:
            print("Ваша версия клиента устарела. Скачайте новую версию.")
            play_sound("LOGOUT.mp3")
            # Не переходим к регистрации/авторизации, просто ждем команд от пользователя
        else:
            # Вводим логин и пароль
            login = input("Введите логин: ")
            password = input("Введите пароль: ")
            client_socket.sendall(f"{login}:{password}".encode("utf-8"))

            # Получаем ответ от сервера (успешная авторизация или регистрация)
            auth_response = client_socket.recv(1024).decode("utf-8")
            print(auth_response)

            if "Успешная" not in auth_response:
                play_sound("LOGOUT.mp3")
                client_socket.close()
                return

            play_sound("LOGIN.mp3")  # Воспроизводим звук успешной авторизации

            # Запрашиваем ID комнаты
            room_id = input("Введите ID комнаты (оставьте пустым, чтобы создать новую): ").strip()
            client_socket.sendall(room_id.encode("utf-8"))

            # Получаем ответ о подключении к комнате
            room_response = client_socket.recv(1024).decode("utf-8")
            print(room_response)

            if "не найдена" in room_response:
                client_socket.close()
                return

            # Запускаем поток для получения сообщений
            threading.Thread(target=receive_messages, args=(client_socket,), daemon=True).start()

        # Основной цикл для отправки сообщений
        while True:
            message = input("Вы: ")
            if message.lower() == "exit":  # Команда для выхода
                print("Отключение от сервера...")
                break
            
            client_socket.sendall(message.encode("utf-8"))

    except (ConnectionResetError, BrokenPipeError):
        print("Соединение потеряно.")
    except KeyboardInterrupt:
        print("\nКлиент завершает работу...")
    except Exception as e:
        print(f"Ошибка: {e}")
    finally:
        play_sound("LOGOUT.mp3")  # Воспроизводим звук отключения
        client_socket.close()  # Закрываем сокет
        print("Клиент отключен.")

if __name__ == "__main__":
    play_sound("IM_ACC.mp3")  # Воспроизводим звук при запуске клиента
    start_client()