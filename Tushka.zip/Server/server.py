import socket
import threading
import json
import os
import random
import string





# Список поддерживаемых версий клиента
SUPPORTED_VERSIONS = ["0.1", "0.2"]

def load_messages(room_id):
    """Загружает сообщения из файла, если он существует, иначе возвращает пустой список."""
    file_path = f"messages_{room_id}.json"
    try:
        if os.path.exists(file_path):
            with open(file_path, "r", encoding="utf-8") as file:
                return json.load(file)  # Загружаем JSON
    except json.JSONDecodeError:
        print(f"Ошибка: Файл {file_path} повреждён, будет создан новый.")
    return []  # Возвращаем пустой список, если файла нет или JSON повреждён


def save_messages(room_id, message_save):
    """Добавляет сообщение в файл и сохраняет его."""
    file_path = f"messages_{room_id}.json"
    try:
        messages = load_messages(room_id)  # Загружаем текущие сообщения
        messages.append(message_save)  # Добавляем новое сообщение

        with open(file_path, "w", encoding="utf-8") as file:
            json.dump(messages, file, ensure_ascii=False, indent=4)  # Сохраняем обратно
    except Exception as e:
        print(f"Ошибка при сохранении сообщений в {file_path}: {e}")

# Функция для загрузки пользователей из файла
def load_users():
    try:
        if os.path.exists("users.json"):
            with open("users.json", "r", encoding="utf-8") as file:
                return json.load(file)
    except json.JSONDecodeError:
        print("Файл users.json содержит некорректный JSON. Будет создан новый файл.")
    return {}

# Функция для сохранения пользователей в файл
def save_users(users):
    try:
        with open("users.json", "w", encoding="utf-8") as file:
            json.dump(users, file, ensure_ascii=False, indent=4)
    except Exception as e:
        print(f"Ошибка при сохранении данных о пользователях: {e}")

# Массив для хранения сообщений
messages = []

# Список подключенных клиентов
clients = []

# Словарь для хранения комнат: {room_id: [client_socket1, client_socket2, ...]}
rooms = {}

# Блокировка для потокобезопасного доступа к clients, messages и rooms
clients_lock = threading.Lock()
messages_lock = threading.Lock()
rooms_lock = threading.Lock()

# Флаг для остановки сервера
server_running = True

# Функция для генерации уникального ID комнаты
def generate_room_id():
    return ''.join(random.choices(string.ascii_uppercase + string.digits, k=6))

# Функция для обработки клиента
def handle_client(client_socket, client_address):
    print(f"Подключен клиент {client_address}")

    try:
        # Получаем версию клиента
        version_info = client_socket.recv(1024).decode("utf-8").strip()

        if not version_info:
            client_socket.sendall("Ошибка: Не получена информация о версии.".encode("utf-8"))
            client_socket.close()
            return

        print(f"Клиент {client_address} использует версию: {version_info}")

        # Проверяем, поддерживается ли версия клиента
        if version_info not in SUPPORTED_VERSIONS:
            client_socket.sendall("Ваша версия устарела. Пожалуйста, обновите приложение.".encode("utf-8"))
            client_socket.close()
            print(f"Клиент {client_address} использует неподдерживаемую версию: {version_info}")
            return

        # Отправляем подтверждение о поддержке версии
        client_socket.sendall("Версия поддерживается. Пожалуйста, авторизуйтесь.".encode("utf-8"))

        # Получаем логин и пароль от клиента
        login_data = client_socket.recv(1024).decode("utf-8").strip()
        if ":" not in login_data:
            client_socket.sendall("Ошибка: Неверный формат данных авторизации.".encode("utf-8"))
            client_socket.close()
            return
        login, password = login_data.split(":")

        # Загружаем актуальные данные о пользователях
        users = load_users()

        # Проверяем, зарегистрирован ли пользователь
        if login in users:
            if users[login] == password:
                client_socket.sendall("Успешная авторизация!".encode("utf-8"))
                print(f"Клиент {client_address} авторизован как {login}")
            else:
                client_socket.sendall("Неверный пароль!".encode("utf-8"))
        else:
            # Регистрируем нового пользователя
            users[login] = password
            save_users(users)
            client_socket.sendall("Успешная регистрация!".encode("utf-8"))
            print(f"Зарегистрирован новый пользователь: {login}")

        # Получаем идентификатор комнаты
        client_socket.sendall("Введите ID комнаты (оставьте пустым, чтобы создать новую):".encode("utf-8"))
        room_id = client_socket.recv(1024).decode("utf-8").strip()

        # Если ID комнаты не введен, создаем новую комнату
        if not room_id:
            room_id = generate_room_id()
            with rooms_lock:
                rooms[room_id] = []
            client_socket.sendall(f"Создана новая комната с ID: {room_id}".encode("utf-8"))
            with open(f"messages_{room_id}.json", "w", encoding="utf-8") as file:
                json.dump([], file, ensure_ascii=False, indent=4)  # Создаём пустой список сообщений
            print(f"Создана новая комната: {room_id}")
        else:
            # Проверяем, существует ли комната
            with rooms_lock:
                if room_id not in rooms:
                    client_socket.sendall("Комната не найдена.".encode("utf-8"))
                    client_socket.close()
                    return
                else:
                    client_socket.sendall(f"Подключение к комнате {room_id}".encode("utf-8"))
                    print(f"Клиент {client_address} подключен к комнате {room_id}")

        # Добавляем клиента в комнату
        with rooms_lock:
            rooms[room_id].append(client_socket)

        # Основной цикл общения
        while True:
            message = client_socket.recv(1024).decode("utf-8").strip()
            if not message:
                break
            print(f"{login} (комната {room_id}): {message}")

            # Сохраняем сообщение в массив
            with messages_lock:
                messages.append((login, message))
            # Пересылаем сообщение всем клиентам в комнате
            with rooms_lock:
                for client in rooms[room_id]:
                    if client != client_socket:
                        message_data = {"user": login, "text": message}
                        print(f"[DEBUG] Сохраняем сообщение в комнате {room_id}: {message}")
                        save_messages(room_id=room_id, message_save={"user": login, "text": message})
                        client.sendall(f"{login}: {message}".encode("utf-8"))
    except (ConnectionResetError, BrokenPipeError):
        print(f"Соединение с клиентом {client_address} потеряно.")
    except Exception as e:
        print(f"Ошибка при обработке клиента {client_address}: {e}")
    finally:
        # Удаляем клиента из комнаты
        with rooms_lock:
            if room_id in rooms and client_socket in rooms[room_id]:
                rooms[room_id].remove(client_socket)
                if not rooms[room_id]:  # Если комната пуста, удаляем её
                    del rooms[room_id]

        with clients_lock:
            clients.remove(client_socket)
        client_socket.close()
        print(f"Клиент {client_address} отключен.")

# Функция для обработки команд сервера
def server_commands():
    global server_running
    while server_running:
        command = input("Введите команду: ").strip().lower()
        if command == "stop_server":
            
            
            server_running = False
            # Закрываем все соединения с клиентами
            with clients_lock:
                for client in clients:
                    try:
                        client.close()
                    except:
                        pass
            break
        elif command.startswith("broadcast"):
            message = command[len("broadcast"):].strip()
            if message:
                with clients_lock:
                    for client in clients:
                        try:
                            client.sendall(f"Сервер: {message}".encode("utf-8"))
                        except:
                            pass
            else:
                print("Ошибка: Укажите сообщение для broadcast.")
        elif command == "reload_users":
            # Обновляем данные о пользователях из файла
            try:
                users = load_users()
                print("Данные о пользователях успешно обновлены.")
            except Exception as e:
                print(f"Ошибка при обновлении данных о пользователях: {e}")
        elif command == "list_rooms":
            with rooms_lock:
                print("Активные комнаты:")
                for room_id, clients_in_room in rooms.items():
                    print(f"Комната {room_id}: {len(clients_in_room)} клиентов")
        else:
            print("Неизвестная команда. Доступные команды: broadcast, stop_server, reload_users, list_rooms")

def start_server(host='0.0.0.0', port=12345):
    global server_running
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind((host, port))
    server_socket.listen(5)
    print(f"Сервер запущен на {host}:{port}")

    # Запускаем поток для обработки команд сервера
    threading.Thread(target=server_commands, daemon=True).start()

    while server_running:
        try:
            client_socket, client_address = server_socket.accept()
            with clients_lock:
                clients.append(client_socket)
            threading.Thread(target=handle_client, args=(client_socket, client_address)).start()
        except OSError:
            # Ошибка возникает при остановке сервера (server_socket закрыт)
            break

    # Закрываем серверный сокет
    server_socket.close()
    print("Сервер остановлен.")

if __name__ == "__main__":
    start_server()